/*function Products(){
 let Pdtjson =    fetch('../json/products.json')
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    console.log(data)
    const JsonPrdts = JSON.stringify(data)

    let ProductsOutput = document.getElementById('ProductsoutPut')
        
    Pdtjson += ProductsOutput .innerHTML = JsonPrdts 
  
  
  
  //`<li>${JsonPrdts}</li><li>${JsonPrdts}</li>`
    
    //Pdtjson += ProductsOutput.innerHTML = JSON.stringify(data)     
  });
    
}*/
function Products(){
     fetch('../json/products.json')
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      console.log(data)
      const JsonPrdts = JSON.stringify(data) 
      let prdtOut = JSON.parse(JsonPrdts)  
      //Men items
      let menItem1 = document.getElementById('MenItem1')
      menItem1.innerHTML ="Men's" + ' ' +  prdtOut.Men[0].Name   + '<br>' + prdtOut.Men[0].img + '<br>' +`${prdtOut.Men[0].Name} ` + "size" + ' '+ prdtOut.Men[0].Size + '<br>'+  prdtOut.Men[1].Color[1] + "<br> " +`<button type="button" class="btn btn-warning btn-sm" onclick="AddprdoutCart()">Add to cart</button>&nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
       
      // Men item2 
       let menItem2 = document.getElementById('MenItem2')
       menItem2.innerHTML ="Men's" + ' ' +  prdtOut.Men[1].Name   + '<br>' + prdtOut.Men[1].img + '<br>' +`${prdtOut.Men[1].Name} ` + "size" + ' '+ prdtOut.Men[1].Size +'<br>'+  prdtOut.Men[1].Color[0]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        // Men item3
        let menItem3 = document.getElementById('MenItem3')
       menItem3.innerHTML ="Men's" + ' ' +  prdtOut.Men[2].Name   + '<br>' + prdtOut.Men[2].img + '<br>' +`${prdtOut.Men[2].Name} ` + "size" + ' '+ prdtOut.Men[2].Size +'<br>'+  prdtOut.Men[2].Color[3]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>` 
        //Men item4
        let menItem4 = document.getElementById('MenItem4')
       menItem4.innerHTML ="Men's" + ' ' +  prdtOut.Men[3].Name   + '<br>' + prdtOut.Men[3].img + '<br>' +`${prdtOut.Men[3].Name} ` + "size" + ' '+ prdtOut.Men[3].Size +'<br>'+  prdtOut.Men[3].Color[1]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        // women Items1
        let womenitems1 = document.getElementById('WomenItems1')
        womenitems1.innerHTML ="Women's" + ' ' +  prdtOut.Women[0].Name   + '<br>' + prdtOut.Women[0].img + '<br>' +`${prdtOut.Women[0].Name} ` + "size" + ' '+ prdtOut.Women[0].Size +'<br>'+  prdtOut.Women[0].Color[1]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        // women Item2
        let womenitems2 = document.getElementById('WomenItems2')
        womenitems2.innerHTML ="Women's" + ' ' +  prdtOut.Women[1].Name   + '<br>' + prdtOut.Women[1].img + '<br>' +`${prdtOut.Women[1].Name} ` + "size" + ' '+ prdtOut.Women[1].Size +'<br>'+  prdtOut.Women[1].Color[1]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        // women Item3
        let womenitem3 = document.getElementById('WomenItems3')
        womenitem3.innerHTML ="Women's" + ' ' +  prdtOut.Women[2].Name   + '<br>' + prdtOut.Women[2].img + '<br>' +`${prdtOut.Women[2].Name} ` + "size" + ' '+ prdtOut.Women[2].Size +'<br>'+  prdtOut.Women[2].Color[1]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm"  onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        //women item4
        let womenitem4 = document.getElementById('WomenItems4')
        womenitem4.innerHTML ="Women's" + ' ' +  prdtOut.Women[3].Name   + '<br>' + prdtOut.Women[3].img + '<br>' +`${prdtOut.Women[3].Name} ` + "size" + ' '+ prdtOut.Women[3].Size +'<br>'+  prdtOut.Women[3].Color[0]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm" >Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button> ` + '<br>' + '<br>' + '<br>'
        //HomeProducts
        let HomeProducts = document.getElementById('HomeProducts')
        HomeProducts.innerHTML ="For Home use" + ' ' +  prdtOut.HomeProducts[0].Name   + '<br>' + prdtOut.HomeProducts[0].img + '<br>' +`${prdtOut.HomeProducts[0].Name} ` + "size" + ' '+ prdtOut.HomeProducts[0].Size +'<br>'+  prdtOut.HomeProducts[0].Color[3]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm" onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        //solar
        let solar = document.getElementById('solar')
        solar.innerHTML ="solar" + ' ' +  prdtOut.Solar[0].Name   + '<br>' + prdtOut.Solar[0].img + '<br>' +`${prdtOut.Solar[0].Name} ` + "size" + ' '+ prdtOut.Solar[0].Size +'<br>'+  prdtOut.Solar[0].Color[0]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm" onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        //Back to School
        let BacktoSchool = document.getElementById('SchoolItems')
        BacktoSchool.innerHTML ="school" + ' ' +  prdtOut.BacktoSchool[0].Name   + '<br>' + prdtOut.BacktoSchool[0].img + '<br>' +`${prdtOut.BacktoSchool[0].Name} ` + "size" + ' '+ prdtOut.BacktoSchool[0].Size +'<br>'+  prdtOut.BacktoSchool[0].Color[4]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm" onclick="AddprdoutCart()" >Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
        //Kid's Toys
        let Kidstoys = document.getElementById('KidToys')
        Kidstoys.innerHTML ="Perfect" + ' ' +  prdtOut.KidsToys[0].Name   + '<br>' + prdtOut.KidsToys[0].img + '<br>' +`${prdtOut.KidsToys[0].Name} ` + "size" + ' '+ prdtOut.KidsToys[0].Size +'<br>'+  prdtOut.KidsToys[0].Color[3]  + "<br> " + `<button type="button" class="btn btn-warning btn-sm" onclick="AddprdoutCart()">Add to cart</button> &nbsp;<b id="OutItems1"></b>&nbsp;<button type="button" onclick="minusItems()">-</button>`
    
    });     
}

// button item function
let prdctvalue = 0;
function AddprdoutCart(){
    let prductValue = document.getElementById('OutItems')
    prductValue.innerHTML = prdctvalue ++ 
      
}
function minusItems(){
    let prductValueM = document.getElementById('OutItems')
    if(prdctvalue != -1){
        prductValueM.innerHTML = prdctvalue -- 
    }
      
}

function CartBtnitems(){
     

}


