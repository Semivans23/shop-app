
const Showpassword = document.getElementById('showPassword');
  const password = document.getElementById('loginPass');

  Showpassword.addEventListener('click', myfunction)    
function myfunction(){
   if(password) {
    password.setAttribute('type',"text")
    Showpassword.innerHTML = `<i id = 'HidePass' onclick="setTimeout(hidePass,100)">hide</i>`   
}
};
     //hide password form
  function hidePass(){
    password.setAttribute('type',"password")
    Showpassword.innerHTML = 'show' 
  }

// sign in to products
/*function signIn(){
let resgisterName = document.getElementById('RuserName').value
let resgisterlogin = document.getElementById('RpassWord').value
let userName = document.getElementById('LoginuserName').value
let userLogin = document.getElementById('loginPass').value
if(resgisterName == userName  && resgisterlogin == userLogin){
 
  let formmsg = document.getElementById('loginMssage');
  formmsg.innerHTML = ' wrong userName or Password'
} 
else {
  location.href =  "products.html"
}}
*/


/*function Accountlink(){
  let showregister = document.getElementById("formRegister")
   showregister.style.display = 'block'
   // hide login
   let hidelogin = document.getElementById("formlogin")
   hidelogin.style.display = "none"

}*/

/*function registerFormHide(){
  let HideRegister = document.getElementById("registerForm")
  HideRegister.style.display = "none"
  let hidelogin = document.getElementById("formlogin")
   hidelogin.style.display = "flex"
}*/