$( function() {
  $( "#MainNavbar" ).button();
   $(".Accountlink").click(function(){
    
    
  
  })
   

} );