const mongoose = require('mongoose');
const login = mongoose.model('login',{userName:{type:String,required:false},
password:{type:String,required:false} });
module.exports = login;

