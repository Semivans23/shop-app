const mongoose = require('mongoose');
//const { schema } = require('./login');

// both a model and schema login
/*const Register = mongoose.model('register', { 
    userName:{type:String, required:false},
    password:{type:String,required:false},
    email:{type:String,required:false}
});*/
// creating schema
const  Register = {
    userName:{type:String, required:false},
    password:{type:String,required:false},
    email:{type:String,required:false}
}
const Registerschema =  mongoose.model('RegisterData',Register)

   // module.exports = Register;
   module.exports = Registerschema;

   

    

    //form validator 


    //Regsiteration 
    //const register = mongoose.model("register", {RegisteruseName:{type:String,required: false},Registerpassword:{type:String,required: false}, pswrepeat:{type:String,required: false}})
    //module.exports = register;
 

  