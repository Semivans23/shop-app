require('./public/dataBase/mongoose');
const registerLogin = require('./public/dataBase/regsiter');
//const loginData = require('./public/dataBase/login');
const express = require('express'); 
const app = express(); 
//const {check} = require('express-validator')
const path = require('path');
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// index.htmls
app.get('/',(req,res)=>{  
res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/index.html'));
    });
   // registration  page
   app.get('/registration.html',(req,res)=>{  

    res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/registration.html'));
    });
    /*
    Posting files always req,res 
    */

    app.post("/regesiter",function(req, res){
        //res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/index.html'));
       /* let Registerlogin = await new  registerLogin.insertMany({
            userName: req.body.userName,
            password: req.body.password,
            email: req.body.email
        });*/

        registerLogin.insertMany([{
            userName: req.body.userName,
            password: req.body.password,
            email: req.body.email
    }]);
       
      // Registerlogin.save();
      // await Registerlogin .insertMany([registerLogin])
       // Registerlogin.save()
        res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/index.html'));
                
            }) 
            //res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/index.html')); 

             
//Post login data
/*[
    check('userName').isLength({minn:3}),
    check('password').isLength({minn:5})
],*/
/*app.post('/login',async(req,res)=>{
    let logData = new loginData({
        userName: req.body.userName,
        password: req.body.password
    })
    logData.save() 
   let registerData = await registerLogin.findOne({},{userName: "$userName",_id:0})

res.send(registerData)
})*/

// login check user 
/*app.post('/login',async(req,res)=>{
    try{
      const loginfo = await registerLogin.findOne({},{userName: "$userName",password:"$password"}) 
       loginfo.find()
      //const loginfo = await registerLogin.find() 
       if (loginfo.userName === req.body.userName && loginfo.password === req.body.password) {
        res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/products.html'));
        console.log(loginfo)
        } 
        else {
           // res.send("wrong password")
            res.status(401).json("Wrong Password");
        }
        
    }
    catch{'wrong'}
   
    
})*/

app.post('/login',async(req,res)=>{
    
    //  const loginfo = await registerLogin.findOne({},{userName: "$userName",password:"$password"}) 
    // await  loginfo.find({userName: "$userName",password:"$password"})
      //const Loginfo = await registerLogin.insertMany({userName: "$userName",password:"$password"})
      const loginfo = await registerLogin.findOne({},{})
      
       if (loginfo.userName === req.body.userName && loginfo.password === req.body.password) {
       // if(Loginfo.userName === req.body.userName && Loginfo.password === req.body.password)
        
        res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/products.html'));
        console.log(loginfo)
     //   console.log(Loginfo)

        } 
        else {
           // res.send("wrong password")
            res.status(401).json("Wrong Password");
        }

   
    
})



   // matching data

/*app.get("/fectch",(req,res)=>{
    dbConn.find()  
    res.send('fd') 
})*/
 
    
       
        
// Products js
/*app.get('*',(req,res)=>{  

res.sendFile(path.join(__dirname, '../ExpressShopping/public/pages/products.html'));
});*/


app.listen(4000,()=>{

    console.log('listerning to port 4000');

});


  